//Sarah Short, October 27, 2024
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

// Class to handle investment calculations
class InvestmentCalculator {
private:
    double initialInvestment;
    double monthlyDeposit;
    double annualInterestRate;
    int numberOfYears;

public:
    // Constructor
    InvestmentCalculator(double initInvest, double monthDep, double interest, int years) {
        initialInvestment = initInvest;
        monthlyDeposit = monthDep;
        annualInterestRate = interest;
        numberOfYears = years;
    }

    // Calculate balance without monthly deposits
    void calculateWithoutMonthlyDeposits() {
        cout << "Balance and Interest Without Additional Monthly Deposits" << endl;
        double balance = initialInvestment;
        for (int year = 1; year <= numberOfYears; ++year) {
            double interest = balance * (annualInterestRate / 100);
            balance += interest;
            cout << "Year " << year << ": Balance: $" << fixed << setprecision(2) << balance
                 << ", Interest: $" << interest << endl;
        }
    }

    // Calculate balance with monthly deposits
    void calculateWithMonthlyDeposits() {
        cout << "Balance and Interest With Additional Monthly Deposits" << endl;
        double balance = initialInvestment;
        for (int year = 1; year <= numberOfYears; ++year) {
            double yearlyInterest = 0;
            for (int month = 1; month <= 12; ++month) {
                double monthlyInterest = (balance + monthlyDeposit) * ((annualInterestRate / 100) / 12);
                yearlyInterest += monthlyInterest;
                balance += monthlyDeposit + monthlyInterest;
            }
            cout << "Year " << year << ": Balance: $" << fixed << setprecision(2) << balance
                 << ", Interest: $" << yearlyInterest << endl;
        }
    }
};

// Main function to drive the program
int main() {
    // Input collection
    double initialInvestment, monthlyDeposit, annualInterestRate;
    int numberOfYears;

    // Getting input from the user
    cout << "Initial Investment Amount: ";
    cin >> initialInvestment;

    cout << "Monthly Deposit: ";
    cin >> monthlyDeposit;

    cout << "Annual Interest (%): ";
    cin >> annualInterestRate;

    cout << "Number of Years: ";
    cin >> numberOfYears;

    // Creating an object of InvestmentCalculator
    InvestmentCalculator calculator(initialInvestment, monthlyDeposit, annualInterestRate, numberOfYears);

    // Calculating balances
    calculator.calculateWithoutMonthlyDeposits();
    cout << endl;
    calculator.calculateWithMonthlyDeposits();

    return 0;
}
